// script.js

$(document).ready(function() {
    // Initialize parallax effect for sections with class 'parallax'
    $('.parallax').parallax();

    // Smooth scrolling for navigation links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();

        $('html, body').animate({
            scrollTop: $($(this).attr('href')).offset().top
        }, 800, 'linear');
    });

    // Change header and background colors on scroll
    $(window).on('scroll', function() {
        const scrollY = $(window).scrollTop();
        const nav = $('header');
        const body = $('body');
        const cartoon = $('#cartoon');

        // Define bright colors for the header background
        const colors = ['#ff6347', '#ffa500', '#ff4500', '#ff1493', '#00ced1'];
        const backgrounds = ['#ffebcd', '#ffe4e1', '#f0e68c', '#e6e6fa', '#add8e6'];

        // Calculate which color to use based on scroll position
        const index = Math.floor(scrollY / (document.body.scrollHeight / colors.length));

        // Apply colors to header and background
        nav.css({
            'background-color': colors[index],
            'color': index % 2 === 0 ? '#fff' : '#000' // Adjust text color based on background brightness
        });
        body.css('background-color', backgrounds[index]);

        // Move cartoon character based on scroll position
        cartoon.css('transform', `translateY(-${scrollY / 2}px)`);

        // Add additional interactive effects to the header
        if (scrollY > 100) {
            nav.addClass('scrolled');
        } else {
            nav.removeClass('scrolled');
        }
    });
});

$(document).ready(function() {
    // Define colors for the header background
    const colors = ['#ff6347', '#ffa500', '#ff4500', '#ff1493', '#00ced1', '#1e90ff', '#20b2aa', '#7fff00', '#ff69b4', '#800080'];
    const numColors = colors.length;

    // Smooth scrolling for navigation links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();

        $('html, body').animate({
            scrollTop: $($(this).attr('href')).offset().top
        }, 800, 'linear');
    });

    // Change header and background colors on scroll
    $(window).on('scroll', function() {
        const scrollY = $(window).scrollTop();
        const nav = $('header');
        const index = Math.floor(scrollY / ($(document).height() / numColors));

        // Apply colors to header
        nav.css({
            'background-color': colors[index],
            'color': index % 2 === 0 ? '#fff' : '#000' // Adjust text color based on background brightness
        });
    });
});

// script.js

$(document).ready(function() {
    // Function to animate scrollbar on scroll
    $(window).scroll(function() {
        var scrollPos = $(this).scrollTop(); // Get current vertical scroll position
        var maxScroll = $(document).height() - $(window).height(); // Get maximum scroll position

        // Calculate the percentage scrolled
        var scrollPercentage = (scrollPos / maxScroll) * 100;

        // Adjust the scrollbar thumb color based on scroll position
        var hue = parseInt(scrollPercentage / 100 * 120); // Adjust the range of colors (0-120)
        $('body').css('scrollbar-color', 'hsl(' + hue + ', 50%, 50%)'); // Set scrollbar color dynamically
    });

    function updateClock() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const timeString = `${hours}:${minutes}:${seconds}`;
        $('#clock').text(timeString);
    }

    setInterval(updateClock, 1000);
    updateClock();
});

